package com.example.bank.management.system.bank.model;

import lombok.Data;
@Data
public class WithDrawal {
    Long account_num;
    Double with_drawal;
}
