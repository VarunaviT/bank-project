package com.example.bank.management.system.bank.model;

import lombok.Data;

@Data
public class Motd {
   private String msg;
   private String url;
}
