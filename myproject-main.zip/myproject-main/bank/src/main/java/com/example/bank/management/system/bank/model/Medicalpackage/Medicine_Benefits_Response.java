package com.example.bank.management.system.bank.model.Medicalpackage;

public class Medicine_Benefits_Response {
    String medicine_benefits;

    public Medicine_Benefits_Response(String medicine_benefits) {
        this.medicine_benefits = medicine_benefits;
    }
}
