package com.example.bank.management.system.bank.model;


import lombok.Data;

@Data
public class Deposit {
    Long account_num;
    Double with_deposit;
}
