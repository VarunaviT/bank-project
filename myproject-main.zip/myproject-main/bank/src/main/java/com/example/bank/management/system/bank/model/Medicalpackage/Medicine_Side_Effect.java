package com.example.bank.management.system.bank.model.Medicalpackage;

import lombok.Data;

@Data
public class Medicine_Side_Effect {
    Long medicine_id;
}
